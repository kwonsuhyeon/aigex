---
name: assessment-html-generator
description: "Generates a clean, interactive paper-exam style HTML quiz page from Korean or Chinese multiple-choice questions (e.g., output from assessment generator or reviewer). Features clean paper typography, answer key & explanation view, score calculation, and bilingual (Korean/Chinese) UI toggle. Use when the user asks to turn quiz questions into an interactive HTML web page or online test paper."
---
# Korean Assessment HTML Generator

An interactive HTML quiz renderer designed to convert Korean and Chinese assessment questions into an elegant, paper-exam style web page.

## Summary

This skill takes final selected multiple-choice questions (from assessment generation/review workflows) and builds a standalone, responsive, single-file HTML interactive quiz. The design emphasizes clean exam-paper typography, high readability, and a bilingual interface switch (Korean / Chinese).

## When to Use

- When the user asks to turn generated or reviewed quiz questions into an interactive web page or HTML quiz.
- When a user wants an interactive test paper preview with answer checking, explanations, and scoring.
- When an interactive assessment tool with Korean/Chinese language switching is required.

## Core Design Principles

1. **Clean Paper Exam Aesthetic (시험지 스타일)**
   - Minimalist, paper-like styling (subtle borders, high-contrast readable font, clean white/off-white background).
   - Avoid dark techy dashboards, excessive neon colors, or overly glossy AI gradients.
   - Clear question numbering, option styling (①②③④ or A/B/C/D), and boxed reading passages (`<pre>` or styled container).

2. **Bilingual UI (한국어 / 中文)**
   - Top navigation bar includes a Language Toggle button (`한국어` / `中文`).
   - Dynamically translates all UI text:
     - Header / Title: `수능/자격증 모의고사` ↔ `模拟考试`
     - Status: `문제 1 / 3` ↔ `第 1 / 3 题`
     - Navigation: `이전` / `다음` ↔ `上一题` / `下一题`
     - Action: `정답 확인` / `제출하기` ↔ `确认答案` / `提交试卷`
     - Explanation: `정답 및 해설` ↔ `正确答案与解析`
     - Score Modal: `최종 점수` ↔ `最终得分`
     - Retry: `다시 풀기` ↔ `重新答题`

3. **Interactive Features**
   - **Mode Option**: Practice Mode (instant feedback & explanation after answering each question) or Test Mode (full submission with final score card).
   - **Visual States**: Hover effects on choices, clear active selection state, distinct green (correct) / red (incorrect) badge highlights when submitted.
   - **Answer Explanations**: Collapsible or pop-up explanation box providing detailed rationale for the correct answer.
   - **Final Score Summary**: Score percentage, correct answer count, and detailed breakdown.

4. **Self-Contained Output**
   - Single standalone HTML file containing standard HTML5, CSS, and Vanilla JavaScript.
   - Responsive design optimized for mobile and desktop screens.
   - No external framework dependencies required.

## Workflow Steps

1. **Extract Question Data**
   Parse the final questions provided by the user (or from previous turns) into a structured JSON structure inside the generated HTML:
   - `id`: Question index
   - `passage`: Reading passage or context (optional)
   - `stem`: Question prompt
   - `options`: List of 4 choices
   - `answer`: Correct option index (1-4)
   - `explanation`: Detailed explanation in Korean/Chinese

2. **Generate Interactive HTML Code**
   Output a single complete HTML snippet enclosed in a clean markdown codeblock or rendered web view. Include:
   - Language selector JS logic.
   - State management for user choices, scored answers, and active question.
   - Paper-like layout styling (`font-family: 'Noto Sans KR', 'Noto Serif KR', sans-serif;`).

3. **Provide Delivery & Guidance**
   Present the generated HTML code clearly, explain how to save/view it, and offer options for modifications (e.g., adding timer, changing mode, adding more questions).
